CREATE DATABASE Library2;

USE Library2;

CREATE TABLE Library2 (
    book_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) UNIQUE NOT NULL,
    author VARCHAR(50),
    price INT DEFAULT 0 CHECK (price <= 1500));

INSERT INTO Library2 (title, author, price)
VALUES 
('The Guide', 'R.K. Narayan', 850),
('Malgudi Days', 'R.K. Narayan', 450),
('Wings of Fire', 'A.P.J. Abdul Kalam', 1200),
('Discovery of India', 'Jawaharlal Nehru', 100);

INSERT INTO Library2 (title, author)
VALUES ('The Secret', 'Rhonda Byrne');

SELECT*FROM Library2;

SELECT * FROM Library2 WHERE price > 1000;

SELECT * FROM Library2 WHERE author = 'R.K. Narayan' OR price < 500;

SELECT DISTINCT author FROM Library2;

SELECT * FROM Library2 ORDER BY price DESC LIMIT 2;

SELECT * FROM Library2 WHERE price BETWEEN 400 AND 1000 ORDER BY price ASC;

SELECT author, COUNT(*) AS total_books FROM Library2 GROUP BY author;

SELECT * FROM Library2 WHERE price = (SELECT MIN(price) FROM Library2);

DROP TABLE IF EXISTS Library2;
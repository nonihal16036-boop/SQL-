CREATE DATABASE Hospital;

USE Hospital;

CREATE TABLE Hospital (
    patient_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_name VARCHAR(50) NOT NULL,
    disease VARCHAR(30),
    bill_amount INT DEFAULT 0 CHECK (bill_amount <= 200000));

INSERT INTO Hospital (patient_name, disease, bill_amount)
VALUES ('Rahul Sharma', 'Flu', 45000),
       ('Priya Verma', 'Typhoid', 120000),
       ('Amit Singh', 'Fever');   

SELECT * FROM Hospital WHERE bill_amount > 50000;

SELECT * FROM Hospital
WHERE disease = 'Flu' OR bill_amount < 10000;

SELECT DISTINCT disease FROM Hospital;

SELECT * FROM Hospital ORDER BY bill_amount DESC LIMIT 2;

SELECT * FROM Hospital WHERE bill_amount BETWEEN 20000 AND 80000 ORDER BY bill_amount ASC;

SELECT disease, COUNT(*) AS total_patients FROM Hospital GROUP BY disease;

SELECT * FROM Hospital
WHERE bill_amount = (SELECT MIN(bill_amount) FROM Hospital);

DROP TABLE IF EXISTS Hospital;
CREATE DATABASE Company;

USE Company;
CREATE TABLE Company (
    emp_id INT PRIMARY KEY AUTO_INCREMENT,
    emp_name VARCHAR(50) NOT NULL,
    department VARCHAR(20),
    salary INT DEFAULT 20000 CHECK (salary >= 20000));

INSERT INTO Company (emp_name, department, salary)
VALUES 
('Alice Johnson', 'HR', 65000),
('Bob Smith', 'IT', 45000),
('Charlie Brown', 'Finance', 90000),
('David Lee', 'HR'),      
('Eve Williams', 'IT', 28000);
SELECT * FROM Company;
SELECT * FROM Company WHERE salary > 50000;

SELECT * FROM Company WHERE department = 'HR' OR salary < 30000;

SELECT DISTINCT department FROM Company;

SELECT * FROM Company ORDER BY salary DESC LIMIT 2;

SELECT * FROM Company WHERE salary BETWEEN 25000 AND 60000 ORDER BY salary ASC;

SELECT department, COUNT(*) AS total_employees FROM Company GROUP BY department;

SELECT emp_name, salary, department FROM Company WHERE salary = (SELECT MAX(salary) FROM Company);

DROP TABLE IF EXISTS Company;
CREATE DATABASE Cinema;

USE Cinema;


CREATE TABLE Cinema (
    movie_id INT PRIMARY KEY AUTO_INCREMENT,
    movie_name VARCHAR(100) UNIQUE NOT NULL,
    language VARCHAR(20),
    rating INT DEFAULT 0 CHECK (rating <= 10));

INSERT INTO Cinema (movie_name, language, rating)
VALUES 
('The Great Escape', 'English', 9),
('Bahubali', 'Telugu', 8),
('Sholay', 'Hindi', 5);

INSERT INTO Cinema (movie_name, language)
VALUES ('Lagaan', 'Hindi');

SELECT * FROM Cinema WHERE rating > 7;

SELECT * FROM Cinema WHERE language = 'Hindi' OR rating < 5;

SELECT DISTINCT language FROM Cinema;

SELECT * FROM Cinema ORDER BY rating DESC LIMIT 2;

SELECT * FROM Cinema WHERE rating BETWEEN 5 AND 9 ORDER BY rating ASC;

SELECT language, COUNT(*) AS total_movies FROM Cinema GROUP BY language;

SELECT * FROM Cinema WHERE rating = (SELECT MAX(rating) FROM Cinema);

DROP TABLE IF EXISTS Cinema;